#!/bin/bash

#docker pull docker-registry.dataflow.global:4443/backend/audit-service:$1
#docker pull docker-registry.dataflow.global:4443/backend/auth-service:$1
#docker pull docker-registry.dataflow.global:4443/backend/datasource-service:$1
docker pull docker-registry.dataflow.global:4443/backend/job-runner:$1
#docker pull docker-registry.dataflow.global:4443/backend/metadata-processor:$1
#docker pull docker-registry.dataflow.global:4443/backend/notification-service:$1
#docker pull docker-registry.dataflow.global:4443/backend/project-executor:$1
#docker pull docker-registry.dataflow.global:4443/backend/project-manager:$1
#docker pull docker-registry.dataflow.global:4443/backend/report-generator:$1
#docker pull docker-registry.dataflow.global:4443/backend/scheduler-service:$1
#docker pull docker-registry.dataflow.global:4443/backend/smp-integrator:$1

#docker tag docker-registry.dataflow.global:4443/backend/audit-service:$1 docker-registry.dataflow.global:4443/backend/audit-service:$2
#docker tag docker-registry.dataflow.global:4443/backend/auth-service:$1 docker-registry.dataflow.global:4443/backend/auth-service:$2
#docker tag docker-registry.dataflow.global:4443/backend/datasource-service:$1 docker-registry.dataflow.global:4443/backend/datasource-service:$2
docker tag docker-registry.dataflow.global:4443/backend/job-runner:$1 docker-registry.dataflow.global:4443/backend/job-runner:$2
#docker tag docker-registry.dataflow.global:4443/backend/metadata-processor:$1 docker-registry.dataflow.global:4443/backend/metadata-processor:$2
#docker tag docker-registry.dataflow.global:4443/backend/notification-service:$1 docker-registry.dataflow.global:4443/backend/notification-service:$2
#docker tag docker-registry.dataflow.global:4443/backend/project-executor:$1 docker-registry.dataflow.global:4443/backend/project-executor:$2
#docker tag docker-registry.dataflow.global:4443/backend/project-manager:$1 docker-registry.dataflow.global:4443/backend/project-manager:$2
#docker tag docker-registry.dataflow.global:4443/backend/report-generator:$1 docker-registry.dataflow.global:4443/backend/report-generator:$2
#docker tag docker-registry.dataflow.global:4443/backend/scheduler-service:$1 docker-registry.dataflow.global:4443/backend/scheduler-service:$2
#docker tag docker-registry.dataflow.global:4443/backend/smp-integrator:$1 docker-registry.dataflow.global:4443/backend/smp-integrator:$2


#docker push docker-registry.dataflow.global:4443/backend/audit-service:$2
#docker push docker-registry.dataflow.global:4443/backend/auth-service:$2
#docker push docker-registry.dataflow.global:4443/backend/datasource-service:$2
docker push docker-registry.dataflow.global:4443/backend/job-runner:$2
#docker push docker-registry.dataflow.global:4443/backend/metadata-processor:$2
#docker push docker-registry.dataflow.global:4443/backend/notification-service:$2
#docker push docker-registry.dataflow.global:4443/backend/project-executor:$2
#docker push docker-registry.dataflow.global:4443/backend/project-manager:$2
#docker push docker-registry.dataflow.global:4443/backend/report-generator:$2
#docker push docker-registry.dataflow.global:4443/backend/scheduler-service:$2
#docker push docker-registry.dataflow.global:4443/backend/smp-integrator:$2
